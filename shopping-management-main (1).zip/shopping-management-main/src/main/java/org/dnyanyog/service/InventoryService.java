package org.dnyanyog.service;

import org.dnynayog.dto.response.InventoryResponse;

public interface InventoryService {

  InventoryResponse getInventory();
	
	
}
